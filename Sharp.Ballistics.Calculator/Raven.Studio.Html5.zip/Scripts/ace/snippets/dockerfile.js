define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./dockerfile.snippets");
exports.scope = "dockerfile";

});
